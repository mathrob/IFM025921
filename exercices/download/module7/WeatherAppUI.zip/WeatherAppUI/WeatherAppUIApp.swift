//
//  WeatherAppUIApp.swift
//  WeatherAppUI
//
//  Created by user240211 on 3/4/24.
//

import SwiftUI

@main
struct WeatherAppUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
