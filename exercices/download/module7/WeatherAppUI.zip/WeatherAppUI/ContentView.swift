//
//  ContentView.swift
//  WeatherAppUI
//
//  Created by user240211 on 3/4/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [.blue, .blue, .blue, .white]), startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
            
            VStack {
                Text("Gatineau, CA")
                    .font(.system(size: 30))
                    .foregroundColor(.white)
                    .padding(.top, 50)
                
                Spacer()
                
                HStack(spacing: 30) {
                    Image(systemName: "cloud.fill")
                        .symbolRenderingMode(.multicolor)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 150, height: 150)
                        .padding(10)
                        .background(Color.gray.opacity(0.8))
                        .clipShape(Circle())
                    
                    VStack(alignment: .leading) {
                        Text("-10 °C")
                            .padding(.bottom, 1)
                            .font(.system(size: 50))
                        Text("T. ressentie : -15")
                            .font(.system(size: 20))
                        Text("Nuageux")
                            .font(.system(size: 20))
                            .bold()
                        Text("Vent : NE 8 km/h")
                            .font(.system(size: 20))
                    }
                }
                .foregroundColor(.white)
                
                Spacer()
                
                VStack {
                    HStack {
                        MeteoParHeure(imageName: "cloud.fill", heure: "10h00", temperature: -9)
                        MeteoParHeure(imageName: "cloud.fill", heure: "11h00", temperature: -5)
                        MeteoParHeure(imageName: "sun.max.fill", heure: "12h00", temperature: -3)
                    }
                    
                    VStack {
                        MoreDetailMenu(imageName: "sun.haze.fill", text: "Lever - Coucher", detailText: "6h45 - 17h47")
                        Divider()
                            .background(Color.blue)
                        MoreDetailMenu(imageName: "humidity.fill", text: "Humidite", detailText: "92 %")
                        Divider()
                            .background(Color.blue)
                        MoreDetailMenu(imageName: "gauge", text: "Pression", detailText: "102 kPa")
                    }
                    .frame(minWidth: 0, maxWidth: .infinity)
                    .padding(8)
                    .background(Color.gray.opacity(0.8))
                }
                
                Spacer()
                
                Image("logoLaCite")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 150)
            }
            .padding(.horizontal, 10)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct MeteoParHeure: View {
    var imageName: String
    var heure: String
    var temperature: Double
    
    var body: some View {
        HStack(spacing: 16) {
            Image(systemName: imageName)
                .symbolRenderingMode(.multicolor)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 38, height: 38)
            
            VStack(alignment: .leading, spacing: 5) {
                Text(heure)
                Text("\(Int(temperature)) °C")
            }
        }
        .frame(minWidth: 0, maxWidth: .infinity)
        .padding(8)
        .background(Color.gray.opacity(0.8))
    }
}

struct MoreDetailMenu: View {
    var imageName: String
    var text: String
    var detailText: String
    
    var body: some View {
        HStack {
            Image(systemName: imageName)
                .symbolRenderingMode(.monochrome)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .foregroundColor(.blue)
                .frame(width: 38, height: 38)
            Text(text)
            
            Spacer()
            
            Text(detailText)
        }
    }
}
