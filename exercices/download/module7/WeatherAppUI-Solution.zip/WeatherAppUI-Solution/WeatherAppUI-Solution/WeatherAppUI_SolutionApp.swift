// WeatherAppUI_SolutionApp.swift
// WeatherAppUI-Solution
//
// Created by Mathieu Robson on 2025-02-24 😎.
// Copyright © 2025 Mathieu Robson. All rights reserved.
//

import SwiftUI

@main
struct WeatherAppUI_SolutionApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
