// WeatherData.swift
// WeatherAppUI-Solution
//
// Created by Mathieu Robson on 2025-02-24 😎.
// Copyright © 2025 Mathieu Robson. All rights reserved.
//


import Foundation

struct WeatherData: Decodable {
    let list: [Forecast]
    let city: City
}

struct Forecast: Decodable {
    let main: Main
    let weather: [Weather]
    let wind: Wind
    let dt: TimeInterval
    let dt_txt: String
}

struct Main: Decodable {
    let temp: Double
    let feels_like: Double
    let temp_min: Double
    let temp_max: Double
    let pressure: Double
    let humidity: Int
}

struct Weather: Decodable {
    let main: String
    let description: String
    let icon: String
}

struct Wind: Decodable {
    let speed: Double
    let deg: Double
}

struct City: Decodable {
    let name: String
    let country: String
    let sunrise: TimeInterval
    let sunset: TimeInterval
}

class WeatherViewModel: ObservableObject {
    @Published var weatherData: WeatherData?
    
    func fetchWeather(city: String) {
        guard let url = URL(string: "https://api.openweathermap.org/data/2.5/forecast?q=\(city)&cnt=4&lang=fr&appid=db86037844ff2011abbcd1d64b38304c&units=metric")
        else {
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data else {
                return
            }
            
            do {
                let decodedResponse = try JSONDecoder().decode(WeatherData.self, from: data)
                DispatchQueue.main.async {
                    self.weatherData = decodedResponse
                }
            } catch {
                print("Error decoding JSON: \(error)")
            }
        }.resume()
    }
    
    func windDirection(degrees: Double) -> String {
        let cardinal = ["N", "NNE", "NE","ENE", "E", "ESE", "SE", "SSE", "S", "SSO", "SO", "OSO", "O", "ONO", "NO", "NNO"]
        let index = Int((degrees / 22.5).rounded()) % cardinal.count
        return cardinal[index]
    }
    
    func timeStringFromUnixTime(unixTime: TimeInterval) -> String {
        let date = Date(timeIntervalSince1970: unixTime)
        let dateFormatter = DateFormatter()
        dateFormatter.timeZone = TimeZone.current
        dateFormatter.dateFormat = "HH:mm"
        return dateFormatter.string(from: date)
    }
    
    func hPaTokPa(_ hPa: Double) -> Double {
        return hPa / 10.0
    }
    
    func icon(iconCode: String) -> String {
        switch iconCode {
        case "01d":
            return "sun.max.fill"
        case "01n":
            return "moon.fill"
        case "02d":
            return "cloud.sun.fill"
        case "02n":
            return "cloud.moon.fill"
        case "03d", "03n":
            return "cloud.fill"
        case "04d", "04n":
            return "cloud.fill"
        case "09d", "09n":
            return "cloud.rain.fill"
        case "10d", "10n":
            return "cloud.heavyrain.fill"
        case "11d", "11n":
            return "cloud.bolt.rain.fill"
        case "13d", "13n":
            return "snowflake"
        case "50d", "50n":
            return "cloud.fog"
        default:
            return "-"
        }
    }
}
