// ContentView.swift
// WeatherAppUI-Solution
//
// Created by Mathieu Robson on 2025-02-24 😎.
// Copyright © 2025 Mathieu Robson. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @StateObject var weatherViewModel = WeatherViewModel()
    @State private var cityTextInput = ""
    @FocusState private var focus: Bool
    
    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [.blue, .blue, .blue, .white]), startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
            
            VStack {
                if let weatherData = weatherViewModel.weatherData {
                    Text("\(weatherData.city.name), \(weatherData.city.country)")
                        .font(.system(size: 30))
                        .foregroundColor(.white)
                        .padding(.top, 50)
                    
                    HStack {
                        TextField("Ville", text: $cityTextInput)
                            .textFieldStyle(.roundedBorder)
                            .onSubmit {
                                weatherViewModel.fetchWeather(city: cityTextInput)
                            }
                            .autocorrectionDisabled(true)
                        
                        Image(systemName: "magnifyingglass")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 20)
                            .foregroundColor(.white)
                    }.padding(20)
                    
                    Spacer()
                    
                    HStack(spacing: 30) {
                        Image(systemName: weatherViewModel.icon(iconCode: weatherData.list.first?.weather.first?.icon ?? ""))
                            .symbolRenderingMode(.multicolor)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 150, height: 150)
                            .padding(10)
                            .background(Color.gray.opacity(0.8))
                            .clipShape(Circle())
                        
                        VStack(alignment: .leading) {
                            Text("\(Int(weatherData.list.first?.main.temp.rounded() ?? 0)) °C")
                                .padding(.bottom, 1)
                                .font(.system(size: 50))
                            Text("T. ressentie : \(Int(weatherData.list.first?.main.feels_like.rounded() ?? 0))")
                                .font(.system(size: 20))
                            Text("\(weatherData.list.first?.weather.first?.description ?? "")")
                                .font(.system(size: 20))
                                .bold()
                            Text("Vent : \(weatherViewModel.windDirection(degrees: weatherData.list.first?.wind.deg ?? 0.0)) \(Int((weatherData.list.first?.wind.speed.rounded() ?? 0) * 3.6)) km/h")
                                .font(.system(size: 20))
                        }
                    }.foregroundColor(.white)
                    
                    Spacer()
                    
                    VStack {
                        HStack {
                            ForEach(weatherData.list.dropFirst().indices, id: \.self) { index in
                                let data = weatherData.list[index]
                                
                                MeteoParHeure(imageName: weatherViewModel.icon(iconCode: data.weather.first?.icon ?? ""), heure: weatherViewModel.timeStringFromUnixTime(unixTime: data.dt), temperature: data.main.temp.rounded())
                            }
                        }
                        
                        VStack {
                            MoreDetailMenu(imageName: "sun.haze.fill", text: "Lever - Coucher", detailText: "\(weatherViewModel.timeStringFromUnixTime(unixTime: weatherData.city.sunrise)) - \(weatherViewModel.timeStringFromUnixTime(unixTime: weatherData.city.sunset))")
                            Divider()
                                .background(Color.blue)
                            MoreDetailMenu(imageName: "humidity.fill", text: "Humidite", detailText: "\(weatherData.list.first?.main.humidity ?? 0) %")
                            Divider()
                                .background(Color.blue)
                            MoreDetailMenu(imageName: "gauge", text: "Pression", detailText: "\(weatherViewModel.hPaTokPa((weatherData.list.first?.main.pressure ?? 0.0))) kPa")
                        }
                        .frame(minWidth: 0, maxWidth: .infinity)
                        .padding(8)
                        .background(Color.gray.opacity(0.8))
                    }
                    
                    Spacer()
                    
                    Image("logoLaCite")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 150)
                } else {
                    
                    VStack {
                        Spacer()
                        
                        Image(systemName: "sun.and.horizon.fill")
                            .symbolRenderingMode(.multicolor)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 300)
                        
                        
                        TextField("Ville", text: $cityTextInput)
                            .textFieldStyle(.roundedBorder)
                            .padding(.horizontal)
                            .onSubmit {
                                weatherViewModel.fetchWeather(city: cityTextInput)
                            }
                            .focused($focus)
                            .autocorrectionDisabled(true)
                        
                        Spacer()
                    }
                    .onAppear {
                        focus = true
                    }
                }
            }
            .padding(.horizontal, 10)
            
        }
    }
}

struct MeteoParHeure: View {
    var imageName: String
    var heure: String
    var temperature: Double
    
    var body: some View {
        HStack(spacing: 16) {
            Image(systemName: imageName)
                .symbolRenderingMode(.multicolor)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 38, height: 38)
            
            VStack(alignment: .leading, spacing: 5) {
                Text(heure)
                Text("\(Int(temperature)) °C")
            }
        }
        .frame(minWidth: 0, maxWidth: .infinity)
        .padding(8)
        .background(Color.gray.opacity(0.8))
    }
}

struct MoreDetailMenu: View {
    var imageName: String
    var text: String
    var detailText: String
    
    var body: some View {
        HStack {
            Image(systemName: imageName)
                .symbolRenderingMode(.monochrome)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .foregroundColor(.blue)
                .frame(width: 38, height: 38)
            Text(text)
            
            Spacer()
            
            Text(detailText)
        }
    }
}

#Preview {
    ContentView()
}


