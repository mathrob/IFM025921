// Musee.swift
// Musee
//
// Created by Mathieu Robson on 2025-03-25 😎.
// Copyright © 2025 Mathieu Robson. All rights reserved.
//

import Foundation
import MapKit

struct Musee: Identifiable, Hashable {
    var id = UUID()
    var nomOfficiel: String
    var nomCommum: String
    var description: String
    var latitude: Double
    var longitude: Double
    var url: String
    var imageName: String

    var mapItem: MKMapItem {
        let coordinate = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        let placemark = MKPlacemark(coordinate: coordinate)
        let mapItem = MKMapItem(placemark: placemark)
        mapItem.name = nomOfficiel
        mapItem.url = URL(string: url)
        return mapItem
    }
}

