// Musees.swift
// Musee
//
// Created by Mathieu Robson on 2025-03-25 😎.
// Copyright © 2025 Mathieu Robson. All rights reserved.
//

import Foundation

let musees = [
    Musee(
        nomOfficiel: "Musée canadien de l'histoire",
        nomCommum: "Musée de l'Histoire",
        description: "Situé sur le territoire traditionnel non cédé du peuple algonquin Anishinabeg, le Musée canadien de l’histoire est le plus grand musée d’histoire humaine au Canada. Chaque année, il accueille des milliers de personnes dans son célèbre complexe situé au cœur de la région de la capitale nationale, ce qui en fait l’un des musées les plus populaires du pays. Inauguré en 1856, le Musée canadien de l’histoire est également une des plus vieilles institutions publiques du Canada. Il gère le Musée canadien de la guerre, fondé en 1880, et le Musée virtuel de la Nouvelle-France, fondé en 1997, en plus d’administrer Musées numériques Canada, dont le financement est assuré par le gouvernement fédéral. Centre respecté d’excellence muséologique, le Musée canadien de l’histoire fait activement connaitre l’histoire humaine et militaire du pays au Canada et dans le monde entier. Tout aussi importante, sa culture organisationnelle est fondée sur les principes de l’équité, de la diversité, de l’inclusion et de l’accessibilité, mettant tout particulièrement l’accent sur l’égalité des chances.",
        latitude: 45.424498302,
        longitude: -75.705330512,
        url: "https://www.museedelhistoire.ca/",
        imageName: "musee_histoire"
    ),
    Musee(
        nomOfficiel: "Musée canadien de la guerre",
        nomCommum: "Musée de la Guerre",
        description: "Chars, chasseurs à réaction, artillerie, œuvres artistiques et plus encore : autant d’éléments impressionnants qui illustrent l’histoire militaire du Canada au Musée canadien de la guerre. L’architecture du bâtiment est basée sur le thème de la régénération, avec des caractéristiques écoénergétiques, comme le toit de verdure, et un symbolisme, comme les fenêtres formant un code morse « N’oublions jamais ». En novembre, le Musée organise des activités et des événements spéciaux de commémoration. Chaque année, le 11 novembre à 11 h, la lumière du soleil entre par la fenêtre unique de la Salle du Souvenir pour illuminer précisément la pierre tombale de la tombe du Soldat inconnu du Canada. Une expérience émouvante!",
        latitude: 45.417156,
        longitude: -75.716829,
        url: "https://www.museedelaguerre.ca/",
        imageName: "musee_guerre"
    ),
    Musee(
        nomOfficiel: "Musée des beaux-arts du Canada",
        nomCommum: "Musée des Beaux-arts",
        description: "Fondé en 1880, le Musée des beaux-arts du Canada joue un rôle clé sur la scène culturelle canadienne depuis plus d’un siècle. Avec des pièces allant des temps anciens à nos jours, le Musée possède une des plus belles collections d’art autochtone et canadien au monde, ainsi que des chefs-d’œuvre de nombreuses autres traditions artistiques. Outre la présentation d’œuvres, le Musée conserve, étudie et fait connaître l’art sous toutes formes de techniques, dont la photographie, la sculpture, la peinture, l’installation et les arts décoratifs. Dans son mandat de partager les arts visuels avec les Canadiens et les Canadiennes, le Musée travaille avec des artistes et des organismes artistiques au pays et à travers le monde pour faire connaître notre histoire collective grâce à l’art. Situé à Ottawa, le Musée est installé dans une structure unique et imposante de verre et de granit conçue par l’architecte de renommée mondiale Moshe Safdie.",
        latitude: 45.429434,
        longitude: -75.698386,
        url: "https://www.beaux-arts.ca",
        imageName: "musee_beaux_arts"
    ),
    Musee(
        nomOfficiel: "Musée des sciences et de la technologie du Canada",
        nomCommum: "Musée des Sciences et Technologie",
        description: "Le Musée des sciences et de la technologie du Canada raconte l’histoire des sciences et de la technologie du Canada au moyen de la découverte, du jeu et de l’apprentissage par l’expérience. Grâce à des expériences quotidiennes, à des expositions interactives et à une remarquable collection d’artefacts, les visiteurs de tous âges apprennent le rôle que joue l’innovation dans la réalisation de notre avenir commun. Les expositions immersives et la programmation du musée sont conçues pour susciter l’intérêt pour les STIAM (sciences, technologie, ingénierie, arts et mathématiques). Les galeries permanentes explorent les principaux progrès de la science et de la technologie, y compris les moyens de transport à vapeur, les technologies sonores, les ressources naturelles et les innovations médicales. Nos expositions inspirantes présentent une vaste collection d’artefacts scientifiques et technologiques de la collection d’Ingenium – des appareils ménagers aux voitures et aux locomotives à vapeur. Fondé en 1967 dans le cadre du projet du centenaire, le musée a fait l’objet d’une rénovation complète et a rouvert ses portes en 2017. L’espace redessiné comprend 11 expositions permanentes ainsi qu’une salle d’exposition temporaire afin d’accueillir des expositions itinérantes du monde entier. La Cuisine bizarre – très prisée des visiteurs – est l’une des deux expositions originales qui subsistent à ce jour, avec l’exposition des locomotives à vapeur.",
        latitude: 45.40351,
        longitude: -75.618906,
        url: "https://ingeniumcanada.org/fr/scitech",
        imageName: "musee_sciences_technologie"
    ),
    Musee(
        nomOfficiel: "Musée de l’agriculture et de l’alimentation du Canada",
        nomCommum: "Musée de l’Agriculture",
        description: "Le Musée de l’agriculture et de l’alimentation du Canada offre l’occasion de découvrir des innovations en sciences et en technologies agricoles ainsi que d’apprendre comment elles ont une incidence sur la vie des Canadiens. Le Musée de l’agriculture et de l’alimentation du Canada est situé à cinq kilomètres de la Colline du Parlement, sur la Ferme expérimentale centrale historique. Le musée est une ferme laitière en exploitation qui abrite diverses races d’animaux de ferme importants pour l’agriculture canadienne – passée et actuelle. Notre étable laitière a été désignée édifice fédéral du patrimoine en 1987. Nos expositions informatives et captivantes abordent des questions clés de notre époque, y compris la sécurité et la littératie alimentaires, l’agriculture durable, les voies alimentaires autochtones et la gérance de l’environnement. Nos expositions présentent des artefacts de la collection d’Ingenium, qui racontent des histoires importantes en matière d’innovation dans l’agriculture et la production alimentaire. Grâce à des expositions captivantes, à des démonstrations alimentaires, à des espaces multisensoriels et à des interactions mémorables avec les animaux, les visiteurs du musée découvrent des innovations dans la production alimentaire à travers le prisme d’une ferme en activité.",
        latitude: 45.387766,
        longitude: -75.709083,
        url: "https://ingeniumcanada.org/fr/agriculture",
        imageName: "musee_agriculture"
    ),
    Musee(
        nomOfficiel: "Musée de l’aviation et de l’espace du Canada",
        nomCommum: "Musée de l'Aviation",
        description: "Le Musée de l’aviation et de l’espace du Canada donne vie à l’aérospatiale canadienne dans un espace qui suscite l’émerveillement. Grâce à des expositions captivantes et à une impressionnante collection d’aéronefs et d’artefacts qui les font voyager dans le temps, les visiteurs ont la chance d’explorer la riche histoire du Canada et ses réalisations dans le domaine de l’aviation et de l’espace. Reconnu comme l’un des plus beaux musées de l’aviation au monde, le Musée de l’aviation et de l’espace du Canada présente plus de 130 aéronefs, à la fois du service civil et militaire. Situé sur une ancienne base militaire à Ottawa, le musée offre aux visiteurs l’occasion de découvrir la riche histoire aérospatiale du Canada dans un contexte international, depuis ses débuts en 1909 à aujourd’hui. Les programmes créatifs et captivants du musée font vivre l’histoire de l’aérospatiale et stimulent un intérêt durable pour l’univers fascinant du transport aérien. Nos principaux sujets d’intérêt comprennent la promotion d’une plus grande appréciation du patrimoine aéronautique du Canada, la démonstration du rôle vital de l’aviation et de l’espace dans la vie des Canadiens, ainsi que l’illustration de l’importance de l’aviation et de l’espace dans la croissance et la prospérité du pays.",
        latitude: 45.457723,
        longitude: -75.642929,
        url: "https://ingeniumcanada.org/fr/aviation",
        imageName: "musee_aviation"
    ),
    Musee(
        nomOfficiel: "Musée canadien de la nature",
        nomCommum: "Musée de la Nature",
        description: "Le Musée canadien de la nature est une institution éducative et scientifique ainsi qu’une destination touristique populaire du centre-ville d’Ottawa, installée dans un édifice historique ressemblant à un château. En tant que musée national d’histoire naturelle du Canada, il s’agit d’un organisme dynamique, à plusieurs niveaux et à multiples facettes, composé de chercheurs scientifiques de renommée mondiale, de spécialistes des collections, de spécialistes de l’éducation et des multimédias, et de professionnels muséaux d’avant-garde. Depuis que le Musée a ouvert ses portes au public en 1912, il s’est efforcé d’accroître les connaissances scientifiques et la compréhension du monde naturel.",
        latitude: 45.41266,
        longitude: -75.68875,
        url: "https://nature.ca/fr/",
        imageName: "musee_nature"
    )
]
