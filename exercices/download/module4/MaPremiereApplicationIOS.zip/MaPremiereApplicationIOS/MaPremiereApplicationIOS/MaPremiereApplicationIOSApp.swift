// MaPremiereApplicationIOSApp.swift
// MaPremiereApplicationIOS
//
// Created by Mathieu Robson on 2025-01-16 😎.
// Copyright © 2025 Mathieu Robson. All rights reserved.
//

import SwiftUI

@main
struct MaPremiereApplicationIOSApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
