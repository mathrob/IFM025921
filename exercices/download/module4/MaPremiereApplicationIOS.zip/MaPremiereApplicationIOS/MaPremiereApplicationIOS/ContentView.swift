// ContentView.swift
// MaPremiereApplicationIOS
//
// Created by Mathieu Robson on 2025-01-15 😎.
// Copyright © 2025 Mathieu Robson. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State private var sliderValue: Double = 1.9
    @State private var text: String = "Hello, World!"
    @State private var selectedColorText: Color = .black
    @State private var selectedColorBackground: Color = .yellow
    
    var body: some View {
        VStack {
            Spacer()
            
            Text("\(text)")
                .scaleEffect(sliderValue)
                .foregroundStyle(selectedColorText)
            
            Button(action: {
                sliderValue = 1.9
                text = "Hello, World!"
                selectedColorText = .black
                selectedColorBackground = .yellow
            }) {
                Text("Reset")
            }
            .padding()
            .foregroundColor(.white)
            .background(Color.red)
            .padding(.top, 30)
            
            Spacer()
            
            Slider(value: $sliderValue, in: 0.5...3.5)
            
            TextField("", text: $text)
                .border(Color.gray)
                .padding()
            
            HStack {
                Text("Couleur du texte:")
                
                Picker("Color", selection: $selectedColorText) {
                    Text("Noir").tag(Color.black)
                    Text("Rouge").tag(Color.red)
                    Text("Bleu").tag(Color.blue)
                }
            }
            
            HStack {
                Text("Couleur du background:")
                
                Picker("Color", selection: $selectedColorBackground) {
                    Text("Jaune").tag(Color.yellow)
                    Text("Vert").tag(Color.green)
                    Text("Orange").tag(Color.orange)
                }
            }
        }
        .background(selectedColorBackground)
    }
}

#Preview {
    ContentView()
}
