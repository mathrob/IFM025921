//
//  Car.swift
//  CarStore
//
//  Created by user240211 on 3/11/24.
//

import SwiftUI

struct Car: Codable, Identifiable {
    var id: String
    var name: String
    var description: String
    var isHybrid: Bool
    var imageName: String
}
