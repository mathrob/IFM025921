//
//  CarStoreApp.swift
//  CarStore
//
//  Created by user240211 on 3/11/24.
//

import SwiftUI

@main
struct CarStoreApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
