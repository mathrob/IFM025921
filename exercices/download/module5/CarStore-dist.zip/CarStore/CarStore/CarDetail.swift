//
//  CarDetail.swift
//  ListNavDemo
//
//  Created by user240211 on 3/10/24.
//

import SwiftUI

struct CarDetail: View {
    let selectedCar: Car
    
    var body: some View {
        Form {
            // A COMPLETER
        }
    }
}

struct CarDetail_Previews: PreviewProvider {
    static var previews: some View {
        CarDetail(selectedCar: carData[0])
    }
}
