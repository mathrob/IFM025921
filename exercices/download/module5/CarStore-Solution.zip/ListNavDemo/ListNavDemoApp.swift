//
//  ListNavDemoApp.swift
//  ListNavDemo
//
//  Created by user240211 on 3/10/24.
//

import SwiftUI

@main
struct ListNavDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
